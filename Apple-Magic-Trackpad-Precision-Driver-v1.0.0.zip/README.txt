﻿========================================================================
   Apple Magic Trackpad Windows Precision Touchpad Driver (v1.0.0)
========================================================================

This driver enables native Windows 10 & 11 Precision Touchpad (PTP) support
for Apple Magic Trackpad (USB-C & Lightning / Bluetooth).

------------------------------------------------------------------------
HOW TO INSTALL:
------------------------------------------------------------------------
1. Right-click "Install-Driver.bat" and select "Run as administrator".
2. Wait a few seconds for Windows to confirm driver installation.
3. Test your trackpad:
   - 2 fingers: Smooth scroll & pinch to zoom
   - 3 fingers swipe up: Task View / Multitasking
   - 3 fingers swipe left/right: Switch apps
   - 4 fingers: Switch virtual desktops
4. Customize all gestures directly in:
   Windows Settings -> Bluetooth & devices -> Touchpad.

------------------------------------------------------------------------
HOW TO UNINSTALL:
------------------------------------------------------------------------
Right-click "Uninstall-Driver.bat" and select "Run as administrator".

------------------------------------------------------------------------
SUPPORTED HARDWARE:
------------------------------------------------------------------------
- Apple Magic Trackpad 3 (USB-C, Late 2024 / M4 - A1535)
- Apple Magic Trackpad 3 & 2 (Lightning - A1535)
- Apple Magic Trackpad 2 (Older revisions)
- Both Bluetooth and USB cable connections.
========================================================================
