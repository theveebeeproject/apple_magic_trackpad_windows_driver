@echo off
setlocal enabledelayedexpansion
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Please right-click this file and select "Run as administrator".
    pause
    exit /b 1
)

echo Searching for installed Apple Precision Trackpad driver...
set FOUND=0
for /f "tokens=1,2 delims=:" %%a in ('pnputil /enum-drivers') do (
    set KEY=%%a
    set VAL=%%b
    set KEY=!KEY: =!
    set VAL=!VAL: =!
    if /i "!KEY!"=="PublishedName" set CURRENT_OEM=!VAL!
    if /i "!KEY!"=="OriginalName" (
        if /i "!VAL!"=="amtptpdevice.inf" (
            echo Found driver: !CURRENT_OEM! ^(amtptpdevice.inf^)
            echo Removing and uninstalling !CURRENT_OEM!...
            pnputil /delete-driver !CURRENT_OEM! /uninstall /force
            set FOUND=1
        )
    )
)

if "%FOUND%"=="0" (
    echo No installed amtptpdevice.inf driver found.
) else (
    echo.
    echo Driver successfully uninstalled.
)
pause
