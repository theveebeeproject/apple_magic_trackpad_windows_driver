@echo off
:: Check for administrative privileges
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo ==========================================================
    echo  ERROR: ADMINISTRATOR RIGHTS REQUIRED
    echo ==========================================================
    echo  Please right-click this file and select:
    echo    "Run as administrator"
    echo.
    pause
    exit /b 1
)

echo.
echo ==========================================================
echo  Installing Apple Magic Trackpad Precision Touchpad Driver
echo  (Microsoft-Signed Native Windows 11 Driver)
echo ==========================================================
echo.

cd /d "%~dp0"
pnputil /add-driver AmtPtpDevice.inf /install

echo.
echo ==========================================================
echo  Installation completed!
echo.
echo  - If your trackpad is connected via Bluetooth or USB-C,
echo    Windows will now recognize it as a native Precision Touchpad!
echo  - Two-finger scrolling, two-finger tap right click, pinch-to-zoom,
echo    and 3-finger / 4-finger gestures will now work natively.
echo  - You can customize all gestures in Windows 11 Settings:
echo      Settings -^> Bluetooth ^& devices -^> Touchpad
echo ==========================================================
echo.
pause
